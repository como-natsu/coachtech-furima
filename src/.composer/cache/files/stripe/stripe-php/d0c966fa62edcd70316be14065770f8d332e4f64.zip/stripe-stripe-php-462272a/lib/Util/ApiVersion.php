<?php

// File generated from our OpenAPI spec

namespace Stripe\Util;

class ApiVersion
{
    const CURRENT = '2026-01-28.clover';
    const CURRENT_MAJOR = 'clover';
}
